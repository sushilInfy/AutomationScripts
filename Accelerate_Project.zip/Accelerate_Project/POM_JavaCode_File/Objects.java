package Sample2;

import org.openqa.selenium.WebDriver;

public class Objects {
	WebDriver driver;
	public Objects(WebDriver driver) {
		this.driver=driver;
	}

	public void ARMP() throws Exception {
		ARMP armp = new ARMP(driver);
		armp.Attribute();
		armp.Plants();
		armp.PQR_View_Manufacturer_Equivalents();
		armp.Lifecycle_Approval_Powerview();
		armp.IP_Classes();
		armp.Organizations();
		armp.Materials_Composition();
		armp.Related_Specifications();
		armp.Master_Specifications();
		armp.Performance_Charcteristic();
		armp.PQR_View_Supplier_Equivalents();
		armp.Security_Classes();
		armp.Files();
		armp.After();
	}
	
	public void DPP() throws Exception {
		DPP dpp = new DPP(driver);
		dpp.Attribute();
		dpp.Weight_Caracteristics();
		dpp.Storage_Transportation_Labeling_Assessment_Data();
		dpp.MarketClearance();
		dpp.Materials_Composition();
		dpp.Plants();
		dpp.Lifecycle_Approval_Powerview();
		dpp.Ownership();
		dpp.IP_Classes();
		dpp.Organizations();
		dpp.Dangerous_Goods_Classification();
		dpp.Global_Harmonized_Standard();
		dpp.Product_Part_Stability_Document();
		dpp.Master_Part_Stability_Document();
		dpp.Notes();
		dpp.SAP_BOM_as_Fed();
		dpp.Bill_of_Materials();
		dpp.Substitues();
		dpp.Related_Specifications();
		dpp.Master_Specifications();
		dpp.Reference_Documents();
		dpp.Performance_Charcteristic();
		dpp.PQR_View_Manufacturer_Equivalents();
		dpp.PQR_View_Supplier_Equivalents();
		dpp.Material_Produced();
		dpp.Security_Classes();
		dpp.Related_ATS();
		dpp.Files();
		dpp.Certifications();
		dpp.After();
	}
	
	public void OPP() throws Exception {
		OPP opp = new OPP(driver);
		opp.Attribute();
		opp.Related_Specifications();
		opp.Plants();
		opp.Ownership();
		opp.IP_Classes();
		opp.Organizations();
		opp.Lifecycle_Approval_Powerview();
		opp.Substances_Materials();
		opp.Materials_Composition();
		opp.Master_Specifications();
		opp.Reference_Documents();
		opp.Performance_Charcteristic();
		opp.PQR_View_Manufacturer_Equivalents();
		opp.PQR_View_Supplier_Equivalents();
		opp.Security_Classes();
		opp.Files();
		opp.After();
	}

}
